package com.example.ffbf;public class RegistrationActivity {
}
